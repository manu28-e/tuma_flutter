# Tuma Flutter Demo

Hii ni Flutter Android demo ya Tuma. Ina dashboard ya fintech, Kiswahili/English language switcher, send money, request money, shop abroad, parcel tracking, trusted marketplace na demo-only protection messaging.

## Build APK kwenye PC

1. Install Flutter stable na Android Studio/Android SDK.
2. Fungua terminal ndani ya folder hii.
3. Run:

```bash
flutter pub get
flutter analyze
flutter build apk --debug
```

APK itapatikana hapa:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

Ipeleke kwenye simu kupitia WhatsApp, Google Drive au USB, kisha ifungue na kuruhusu **Install unknown apps** ikiwa Android itauliza.

## Run moja kwa moja kwenye simu iliyounganishwa

Washa Developer options na USB debugging, unganisha simu, halafu run:

```bash
flutter devices
flutter run
```

## Muhimu

Hii ni demo ya UI na local state. Haifanyi payment halisi, authentication, KYC/AML au delivery API. Production version itaunganisha Flutter client na FastAPI + Supabase backend kwa server-authoritative ledger, auth, orders, tracking, webhooks na protected payments.
