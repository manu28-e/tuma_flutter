package com.tuma.tuma

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
