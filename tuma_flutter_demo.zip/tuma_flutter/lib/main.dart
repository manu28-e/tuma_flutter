import 'package:flutter/material.dart';

void main() => runApp(const TumaApp());

class TumaApp extends StatelessWidget {
  const TumaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Tuma',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F8F4),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB6F36B),
          brightness: Brightness.light,
        ),
        fontFamily: 'sans',
      ),
      home: const TumaHome(),
    );
  }
}

class TumaHome extends StatefulWidget {
  const TumaHome({super.key});
  @override
  State<TumaHome> createState() => _TumaHomeState();
}

class _TumaHomeState extends State<TumaHome> {
  bool swahili = true;
  int tab = 0;
  String toast = '';

  String tr(String sw, String en) => swahili ? sw : en;

  void showMessage(String value) {
    setState(() => toast = value);
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) setState(() => toast = '');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            IndexedStack(
              index: tab,
              children: [
                _dashboard(),
                _movePage(),
                _ordersPage(),
                _profilePage(),
              ],
            ),
            if (toast.isNotEmpty)
              Positioned(left: 16, right: 16, bottom: 12, child: _toast()),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFE6F8CB),
        onDestinationSelected: (value) => setState(() => tab = value),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.home_outlined),
            selectedIcon: const Icon(Icons.home),
            label: tr('Mwanzo', 'Home'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.account_balance_wallet_outlined),
            selectedIcon: const Icon(Icons.account_balance_wallet),
            label: tr('Tuma pesa', 'Move'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.inventory_2_outlined),
            selectedIcon: const Icon(Icons.inventory_2),
            label: tr('Maagizo', 'Orders'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.person_outline),
            selectedIcon: const Icon(Icons.person),
            label: tr('Wasifu', 'Profile'),
          ),
        ],
      ),
    );
  }

  Widget _dashboard() {
    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(child: _topBar()),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              _demoLabel(),
              const SizedBox(height: 10),
              Text(
                tr('Habari, Amina.', 'Good afternoon, Amina.'),
                style: const TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -1.2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                tr(
                  'Sogeza thamani, bidhaa na uaminifu kuvuka mipaka.',
                  'Move value, goods and trust across borders.',
                ),
                style: const TextStyle(color: Color(0xFF718079), fontSize: 13),
              ),
              const SizedBox(height: 22),
              _balanceCard(),
              const SizedBox(height: 12),
              _trustCard(),
              const SizedBox(height: 28),
              _sectionTitle(
                tr('Unafanya nini leo?', 'What are you doing today?'),
              ),
              const SizedBox(height: 12),
              _quickGrid(),
              const SizedBox(height: 28),
              _sectionTitle(tr('Shughuli za hivi karibuni', 'Recent activity')),
              const SizedBox(height: 8),
              _activityCard(),
              const SizedBox(height: 28),
              _sectionTitle(tr('Agizo linaloendelea', 'Active order')),
              const SizedBox(height: 8),
              _orderCard(),
              const SizedBox(height: 28),
              _marketplaceCard(),
            ]),
          ),
        ),
      ],
    );
  }

  Widget _topBar() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
    child: Row(
      children: [
        Row(
          children: [
            Transform.rotate(
              angle: -.55,
              child: Container(
                width: 10,
                height: 25,
                decoration: BoxDecoration(
                  color: const Color(0xFF0B1514),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(width: 5),
            Transform.rotate(
              angle: -.55,
              child: Container(
                width: 10,
                height: 18,
                decoration: BoxDecoration(
                  color: const Color(0xFF86BF3D),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            const SizedBox(width: 7),
            const Text(
              'tuma',
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.w800,
                letterSpacing: -1.2,
              ),
            ),
          ],
        ),
        const Spacer(),
        OutlinedButton.icon(
          onPressed: () => setState(() => swahili = !swahili),
          icon: const Icon(Icons.language, size: 16),
          label: Text(
            swahili ? 'SW' : 'EN',
            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
          ),
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: Color(0xFFE4EAE1)),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
            minimumSize: Size.zero,
          ),
        ),
        const SizedBox(width: 6),
        IconButton(
          onPressed: () =>
              showMessage(tr('Hakuna taarifa mpya', 'No new notifications')),
          icon: const Icon(Icons.notifications_none, size: 21),
        ),
        const CircleAvatar(
          radius: 17,
          backgroundColor: Color(0xFFFFE0C9),
          child: Text(
            'AM',
            style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800),
          ),
        ),
      ],
    ),
  );

  Widget _demoLabel() => Row(
    children: [
      const Icon(Icons.auto_awesome, size: 14, color: Color(0xFF68953C)),
      const SizedBox(width: 6),
      Text(
        tr('DEMO • HAKUNA MALIPO HALISI', 'DEMO • NO REAL PAYMENTS'),
        style: const TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w800,
          color: Color(0xFF68953C),
          letterSpacing: .8,
        ),
      ),
    ],
  );

  Widget _balanceCard() => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: const Color(0xFF0B1514),
      borderRadius: BorderRadius.circular(22),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              tr('Salio lako', 'Your balance'),
              style: const TextStyle(color: Color(0xFF9FADA5), fontSize: 10),
            ),
            const Spacer(),
            _chip(Icons.account_balance_wallet, 'USD wallet'),
          ],
        ),
        const SizedBox(height: 10),
        const Text(
          r'$2,480.50',
          style: TextStyle(
            color: Colors.white,
            fontSize: 36,
            fontWeight: FontWeight.w700,
            letterSpacing: -1.5,
          ),
        ),
        const SizedBox(height: 5),
        Row(
          children: [
            Container(
              width: 7,
              height: 7,
              decoration: const BoxDecoration(
                color: Color(0xFF71BD3F),
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              tr('Inapatikana sasa', 'Available now'),
              style: const TextStyle(color: Color(0xFFB5C1BA), fontSize: 10),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Row(
          children: [
            const Text(
              '•••• 2048',
              style: TextStyle(
                color: Color(0xFF899990),
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
            const Spacer(),
            TextButton(
              onPressed: () => showMessage(
                tr(
                  'Demo iko tayari kwa payment integration',
                  'Demo is ready for payment integration',
                ),
              ),
              child: Text(
                tr('Ongeza pesa', 'Add money'),
                style: const TextStyle(
                  color: Color(0xFFB6F36B),
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _trustCard() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: const Color(0xFFEEF7E7),
      border: Border.all(color: const Color(0xFFDDE8D8)),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: const BoxDecoration(
            color: Color(0xFFB6F36B),
            shape: BoxShape.circle,
          ),
          child: const Icon(
            Icons.verified_user_outlined,
            color: Color(0xFF4B7929),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'TUMA TRUST LAYER',
                style: TextStyle(
                  color: Color(0xFF73925B),
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: .7,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                tr('Protected mpaka delivery', 'Protected until delivery'),
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                tr(
                  'Pesa inabaki salama mpaka bidhaa ifike.',
                  'Your money stays protected until delivery.',
                ),
                style: const TextStyle(color: Color(0xFF71806F), fontSize: 10),
              ),
            ],
          ),
        ),
        const Icon(Icons.chevron_right, color: Color(0xFF83A66A)),
      ],
    ),
  );

  Widget _quickGrid() {
    final actions = [
      [
        Icons.north_east,
        tr('Tuma pesa', 'Send money'),
        'US → TZ · 1–2 min',
        const Color(0xFF172120),
        Colors.white,
      ],
      [
        Icons.south_west,
        tr('Omba pesa', 'Request money'),
        'Secure link',
        Colors.white,
        const Color(0xFF0B1514),
      ],
      [
        Icons.shopping_bag_outlined,
        tr('Agiza bidhaa', 'Shop abroad'),
        'Global → door',
        const Color(0xFFB6F36B),
        const Color(0xFF0B1514),
      ],
      [
        Icons.local_shipping_outlined,
        tr('Tuma mzigo', 'Send a parcel'),
        'Local & cross-border',
        const Color(0xFFFFE0C9),
        const Color(0xFF0B1514),
      ],
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: actions.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 1.25,
      ),
      itemBuilder: (context, i) {
        final a = actions[i];
        final bg = a[3] as Color;
        final fg = a[4] as Color;
        return InkWell(
          onTap: () => _openAction(i),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: bg == Colors.white
                    ? const Color(0xFFE7EBE5)
                    : Colors.transparent,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 31,
                  height: 31,
                  decoration: BoxDecoration(
                    color: bg == Colors.white
                        ? const Color(0xFFF0F3EE)
                        : Colors.white.withValues(alpha: .2),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(a[0] as IconData, size: 18, color: fg),
                ),
                const Spacer(),
                Text(
                  a[1] as String,
                  style: TextStyle(
                    color: fg,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  a[2] as String,
                  style: TextStyle(
                    color: fg == Colors.white
                        ? const Color(0xFF9EAAA4)
                        : const Color(0xFF65736B),
                    fontSize: 9,
                  ),
                ),
                const Align(
                  alignment: Alignment.bottomRight,
                  child: Icon(Icons.chevron_right, size: 15),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _sectionTitle(String title) => Row(
    children: [
      Expanded(
        child: Text(
          title,
          style: const TextStyle(
            fontSize: 19,
            fontWeight: FontWeight.w800,
            letterSpacing: -.5,
          ),
        ),
      ),
      Text(
        tr('Angalia zote', 'View all'),
        style: const TextStyle(
          color: Color(0xFF719847),
          fontSize: 10,
          fontWeight: FontWeight.w700,
        ),
      ),
    ],
  );

  Widget _activityCard() => _panel(
    Column(
      children: [
        _activity(
          Icons.south_west,
          'Money received',
          'From James M.',
          '+\$240.00',
          true,
          'Today, 10:42',
        ),
        _activity(
          Icons.north_east,
          'Order protected',
          'MacBook Air M3 · TU-2048',
          '-\$1,180.00',
          false,
          'Yesterday, 16:08',
        ),
        _activity(
          Icons.north_east,
          'Delivery fee',
          'Afya Botanics · TU-1974',
          '-\$12.50',
          false,
          'Oct 24, 09:12',
        ),
      ],
    ),
  );
  Widget _activity(
    IconData icon,
    String title,
    String sub,
    String amount,
    bool positive,
    String time,
  ) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: positive ? const Color(0xFFE8F6D8) : const Color(0xFFF0F3EF),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(
            icon,
            size: 16,
            color: positive ? const Color(0xFF5B8E2D) : const Color(0xFF798680),
          ),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                sub,
                style: const TextStyle(color: Color(0xFF9AA49F), fontSize: 9),
              ),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              amount,
              style: TextStyle(
                color: positive
                    ? const Color(0xFF6CA436)
                    : const Color(0xFF4F5B56),
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              time,
              style: const TextStyle(color: Color(0xFF9AA49F), fontSize: 9),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _orderCard() => _panel(
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: const Color(0xFFE4F4CA),
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(
                Icons.inventory_2_outlined,
                color: Color(0xFF5F744A),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'MacBook Air M3',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'TechNest London · TU-2048',
                    style: TextStyle(color: Color(0xFF99A39E), fontSize: 9),
                  ),
                ],
              ),
            ),
            _status(tr('Iko njiani', 'In transit')),
          ],
        ),
        const SizedBox(height: 18),
        Row(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'London',
                  style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700),
                ),
                const Text(
                  'Oct 30',
                  style: TextStyle(color: Color(0xFF9AA49F), fontSize: 8),
                ),
              ],
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    height: 4,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE9EEE7),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                  FractionallySizedBox(
                    widthFactor: .66,
                    alignment: Alignment.centerLeft,
                    child: Container(
                      height: 4,
                      decoration: BoxDecoration(
                        color: const Color(0xFF86BF3D),
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                  const Align(
                    alignment: Alignment(.32, 0),
                    child: CircleAvatar(
                      radius: 5,
                      backgroundColor: Color(0xFF86BF3D),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Text(
                  'Dar es Salaam',
                  style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700),
                ),
                Text(
                  tr('Inafika Nov 08', 'Arrives Nov 08'),
                  style: const TextStyle(color: Color(0xFF9AA49F), fontSize: 8),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 17),
        OutlinedButton(
          onPressed: () => setState(() => tab = 2),
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(double.infinity, 36),
            side: const BorderSide(color: Color(0xFFE7EBE5)),
          ),
          child: Text(
            tr('Fuatilia', 'Track'),
            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
          ),
        ),
      ],
    ),
  );

  Widget _marketplaceCard() => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: const Color(0xFFEDF0FF),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          tr('MARKETPLACE INAYOAMINIKA', 'TRUSTED MARKETPLACE'),
          style: const TextStyle(
            color: Color(0xFF7580B5),
            fontSize: 9,
            fontWeight: FontWeight.w800,
            letterSpacing: .7,
          ),
        ),
        const SizedBox(height: 7),
        Text(
          tr(
            'Bidhaa kutoka kwa sellers waliothibitishwa',
            'Goods from verified sellers',
          ),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 14),
        ...['TechNest London', 'Afya Botanics', 'Kijiji Crafts'].map(
          (name) => Padding(
            padding: const EdgeInsets.only(bottom: 7),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: .72),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 14,
                    backgroundColor: const Color(0xFFDFF7BA),
                    child: Text(
                      name.substring(0, 2).toUpperCase(),
                      style: const TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      name,
                      style: const TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const Icon(
                    Icons.verified,
                    size: 13,
                    color: Color(0xFF6CA538),
                  ),
                  const SizedBox(width: 5),
                  const Text(
                    '★ 4.9',
                    style: TextStyle(fontSize: 9, color: Color(0xFF777E9C)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    ),
  );

  Widget _panel(Widget child) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
    decoration: BoxDecoration(
      color: Colors.white,
      border: Border.all(color: const Color(0xFFE7EBE5)),
      borderRadius: BorderRadius.circular(18),
    ),
    child: child,
  );
  Widget _chip(IconData icon, String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: .08),
      border: Border.all(color: Colors.white.withValues(alpha: .1)),
      borderRadius: BorderRadius.circular(30),
    ),
    child: Row(
      children: [
        Icon(icon, size: 13, color: const Color(0xFFB6F36B)),
        const SizedBox(width: 5),
        Text(
          text,
          style: const TextStyle(
            color: Color(0xFFB6F36B),
            fontSize: 9,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    ),
  );
  Widget _status(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
    decoration: BoxDecoration(
      color: const Color(0xFFEEF8DD),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      children: [
        const CircleAvatar(radius: 3, backgroundColor: Color(0xFF6B913D)),
        const SizedBox(width: 4),
        Text(
          text,
          style: const TextStyle(
            color: Color(0xFF6B913D),
            fontSize: 8,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    ),
  );
  Widget _toast() => Material(
    color: Colors.transparent,
    child: Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFDDE9D8)),
        borderRadius: BorderRadius.circular(13),
        boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 18)],
      ),
      child: Row(
        children: [
          const Icon(Icons.check_circle, color: Color(0xFF6CA436), size: 20),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              toast,
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    ),
  );

  void _openAction(int index) {
    if (index == 0 || index == 1) _showMoneySheet(index == 0);
    if (index == 2) _showOrderSheet();
    if (index == 3) {
      setState(() => tab = 2);
      showMessage(
        tr('Chagua order yako kwa delivery', 'Choose an order for delivery'),
      );
    }
  }

  void _showMoneySheet(bool send) {
    final amount = TextEditingController(text: '240');
    final person = TextEditingController(text: 'James M.');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (context) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          12,
          20,
          MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFDCE3D9),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 22),
            Text(
              send
                  ? tr('Tuma pesa', 'Send money')
                  : tr('Omba pesa', 'Request money'),
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 18),
            Text(
              tr('Unamtumia nani?', 'Who are you sending to?'),
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            TextField(
              controller: person,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.person_outline),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 13),
            Text(
              tr('Kiasi', 'Amount'),
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            TextField(
              controller: amount,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                prefixText: '\$',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFF0F8E7),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.verified_user_outlined,
                    color: Color(0xFF6B913D),
                    size: 17,
                  ),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      tr(
                        'Hii ni demo. Hakuna pesa itakayotumwa.',
                        'This is a demo. No money will move.',
                      ),
                      style: const TextStyle(
                        color: Color(0xFF6B913D),
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  Navigator.pop(context);
                  showMessage(
                    send
                        ? tr(
                            'Preview ya kutuma imekamilika',
                            'Send preview complete',
                          )
                        : tr('Request imeundwa', 'Request created'),
                  );
                },
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFB6F36B),
                  foregroundColor: const Color(0xFF0B1514),
                  padding: const EdgeInsets.all(15),
                ),
                child: Text(
                  tr('Thibitisha', 'Confirm'),
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showOrderSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (context) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          12,
          20,
          MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFDCE3D9),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 22),
            Text(
              tr('Agiza bidhaa', 'Shop abroad'),
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 18),
            Text(
              tr('Unataka kuagiza nini?', 'What do you want to order?'),
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            const TextField(
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.shopping_bag_outlined),
                hintText: 'MacBook kutoka London',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 13),
            Text(
              tr('Itapelekwa wapi?', 'Where should it go?'),
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            const TextField(
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.location_on_outlined),
                hintText: 'Dar es Salaam, Tanzania',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() => tab = 2);
                  showMessage(
                    tr('Request ya order imeundwa', 'Order request created'),
                  );
                },
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFFB6F36B),
                  foregroundColor: const Color(0xFF0B1514),
                  padding: const EdgeInsets.all(15),
                ),
                child: Text(
                  tr('Linganisha quotes', 'Compare quotes'),
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _movePage() => _simplePage(
    Icons.account_balance_wallet_outlined,
    tr('Tuma pesa', 'Move money'),
    tr(
      'Routes rahisi, ada wazi na confirmation kabla ya kutuma.',
      'Simple routes, clear fees and confirmation before money moves.',
    ),
    [tr('Tuma pesa', 'Send money'), tr('Omba pesa', 'Request money')],
  );
  Widget _ordersPage() => _simplePage(
    Icons.inventory_2_outlined,
    tr('Maagizo yako', 'Your orders'),
    tr(
      'Fuatilia bidhaa, seller na delivery katika sehemu moja.',
      'Track goods, sellers and delivery in one place.',
    ),
    ['MacBook Air M3 · TU-2048', 'Organic skincare · TU-1974'],
  );
  Widget _profilePage() => _simplePage(
    Icons.person_outline,
    tr('Wasifu', 'Profile'),
    tr(
      'Simamia lugha, usalama na taarifa zako.',
      'Manage language, security and your account.',
    ),
    [
      tr('Lugha: ', 'Language: ') + (swahili ? 'Kiswahili' : 'English'),
      tr('Identity verified', 'Identity verified'),
    ],
  );
  Widget _simplePage(
    IconData icon,
    String title,
    String subtitle,
    List<String> items,
  ) => ListView(
    padding: const EdgeInsets.fromLTRB(16, 25, 16, 30),
    children: [
      Row(
        children: [
          Icon(icon, size: 22),
          const SizedBox(width: 9),
          Text(
            title,
            style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800),
          ),
        ],
      ),
      const SizedBox(height: 9),
      Text(
        subtitle,
        style: const TextStyle(color: Color(0xFF718079), fontSize: 13),
      ),
      const SizedBox(height: 22),
      ...items.map(
        (item) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: _panel(
            ListTile(
              title: Text(
                item,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
              trailing: const Icon(Icons.chevron_right),
            ),
          ),
        ),
      ),
    ],
  );
}
